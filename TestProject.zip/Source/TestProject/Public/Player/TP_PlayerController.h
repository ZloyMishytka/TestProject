// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "TP_PlayerPawn.h"
#include "Game/TP_PlayerState.h"
#include "GameFramework/PlayerController.h"
#include "TP_PlayerController.generated.h"

/**
 * 
 */
UCLASS()
class TESTPROJECT_API ATP_PlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void AddGoal();
	
	UFUNCTION(Server, Reliable)
	void Server_AddGoal();
	
	UFUNCTION(Client, Unreliable)
	void Client_ShowWaitPlayerWidget();

	UFUNCTION(Client, Unreliable)
	void Client_HideWaitPlayerWidget();

	UFUNCTION(Client, Unreliable)
	void Client_ShowPlayerHUDWidget();

	UFUNCTION(Client, Unreliable)
	void Client_HidePlayerHUDWidget();
	
	UPROPERTY(Replicated)
	AActor* PlayerStart = nullptr;
	
protected:
	virtual void BeginPlay() override;
	virtual void SetupInputComponent() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = MovePlatform)
	float SpeedModify = 10.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = MovePlatform)
	float TraceMaxDistance = 300.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = MovePlatform)
	TSubclassOf<ATP_PlayerPawn> PlayerClass;
private:
	UFUNCTION(Client, Reliable)
	void Client_StartGame();

	UFUNCTION(Server, Reliable)
	void Server_SpawnPlayer();
	
	UFUNCTION()
	void MoveRight(float Amount);
	
	UFUNCTION(Server, Reliable)
	void Server_MoveRight(float Amount);
	
	bool TraceMove(float Amount, UPrimitiveComponent* ComponentLocation);

	ATP_PlayerState* PlayerState = nullptr;
};
