// Fill out your copyright notice in the Description page of Project Settings.


#include "Game/TP_BaseGameMode.h"
#include "GameFramework/GameSession.h"
#include "GameFramework/PlayerStart.h"
#include "Kismet/GameplayStatics.h"
#include "Player/TP_PlayerController.h"

void ATP_BaseGameMode::BeginPlay()
{
	Super::BeginPlay();

	OnGoalSignature.AddDynamic(this, &ATP_BaseGameMode::SpawnBall);
	
	if(!GetWorld()) return;

	GetWorld()->GetTimerManager().SetTimer(WaitPlayersTimerHandle, this, &ATP_BaseGameMode::WaitPlayers, 0.01f, true, 0.0f);
}

void ATP_BaseGameMode::WaitPlayers()
{
	TArray<AActor*> Controllers;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), APlayerController::StaticClass(), Controllers);

	if(Controllers.Num() < CountPlayers)
	{
		for (auto PlayerControl : Controllers)
		{
			ATP_PlayerController* PlayerController = Cast<ATP_PlayerController>(PlayerControl);
			if(PlayerController)
			{
				PlayerController->Client_ShowWaitPlayerWidget();
			}
		}
	}
	else
	{
		if(Controllers.Num() > CountPlayers)
		{
			return;
		}
		TArray<AActor*> PlayersStarts;
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), APlayerStart::StaticClass(), PlayersStarts);
		if(PlayersStarts.Num() < CountPlayers)
		{
			GetWorld()->GetTimerManager().ClearTimer(WaitPlayersTimerHandle);
			return;
		}
		int32 IndexPlayerStart = 0;
		for (auto PlayerControl : Controllers)
		{
			ATP_PlayerController* PlayerController = Cast<ATP_PlayerController>(PlayerControl);
			if(PlayerController)
			{
				PlayersControllers.Add(PlayerController);
				PlayerController->PlayerStart = PlayersStarts[IndexPlayerStart];
				IndexPlayerStart++;
			}
		}
		StartGame();
	}
	
}

void ATP_BaseGameMode::StartGame()
{
	GetWorld()->GetTimerManager().ClearTimer(WaitPlayersTimerHandle);
	OnStartGameSignature.Broadcast();
	SpawnBall();
}

void ATP_BaseGameMode::SpawnBall()
{
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("Try!"));
	if(!GetWorld() || PointSpawnBall.IsZero() || !BallClass) return;
	if(BallRef)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("Destroy!"));
		BallRef->Destroy();
	}
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("Spawn!"));
	FActorSpawnParameters SpawnInfo;
	BallRef = GetWorld()->SpawnActor<ATP_BallActor>(BallClass, PointSpawnBall, FRotator::ZeroRotator, SpawnInfo);
}

