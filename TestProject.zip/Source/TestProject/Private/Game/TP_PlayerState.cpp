// Fill out your copyright notice in the Description page of Project Settings.


#include "Game/TP_PlayerState.h"
#include "Net/UnrealNetwork.h"

DEFINE_LOG_CATEGORY_STATIC(LogPlayerState, All, All);

void ATP_PlayerState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ATP_PlayerState, CountGoals);
}

void ATP_PlayerState::AddGoal()
{
	CountGoals++;
	OnRep_CountGoals();
}

void ATP_PlayerState::OnRep_CountGoals()
{
	UE_LOG(LogPlayerState, Display, TEXT("PlayerState: %s. Score: %i"), *GetName(), CountGoals);
}