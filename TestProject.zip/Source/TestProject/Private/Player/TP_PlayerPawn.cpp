// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/TP_PlayerPawn.h"
#include "Camera/CameraComponent.h"

ATP_PlayerPawn::ATP_PlayerPawn()
{
	PrimaryActorTick.bCanEverTick = true;

	SceneComponent = CreateDefaultSubobject<USceneComponent>("RootScene");
	SetRootComponent(SceneComponent);
	CameraComponent = CreateDefaultSubobject<UCameraComponent>("PlayerCamera");
	CameraComponent->SetupAttachment(SceneComponent);
	MeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("StaticMesh");
	MeshComponent->SetupAttachment(SceneComponent);
	ArrowComponent = CreateDefaultSubobject<UArrowComponent>("Arrow");
	ArrowComponent->SetupAttachment(MeshComponent);

	MeshComponent->SetIsReplicated(true);
}

void ATP_PlayerPawn::BeginPlay()
{
	Super::BeginPlay();
	
}

void ATP_PlayerPawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

