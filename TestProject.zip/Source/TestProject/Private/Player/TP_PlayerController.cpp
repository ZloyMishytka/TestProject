// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/TP_PlayerController.h"
#include "CollisionDebugDrawingPublic.h"
#include "Blueprint/UserWidget.h"
#include "Game/TP_BaseGameMode.h"
#include "Game/TP_BaseHUD.h"
#include "Game/TP_PlayerState.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"


void ATP_PlayerController::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ATP_PlayerController, PlayerStart);
}

void ATP_PlayerController::BeginPlay()
{
	Super::BeginPlay();

	if(!GetWorld()) return;
	const auto GameMode = Cast<ATP_BaseGameMode>(UGameplayStatics::GetGameMode(GetWorld()));
	if(!GameMode) return;
	GameMode->OnStartGameSignature.AddDynamic(this, &ATP_PlayerController::Client_StartGame);
	PlayerState = GetPlayerState<ATP_PlayerState>();
}

void ATP_PlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	InputComponent->BindAxis("Move", this, &ATP_PlayerController::MoveRight);
}

void ATP_PlayerController::Client_StartGame_Implementation()
{
	Client_HideWaitPlayerWidget();
	Server_SpawnPlayer();
}

void ATP_PlayerController::Server_SpawnPlayer_Implementation()
{
	if(!GetWorld() || !PlayerStart || !PlayerClass) return;
	FActorSpawnParameters SpawnInfo;
	ATP_PlayerPawn* PlayerPawn = GetWorld()->SpawnActor<ATP_PlayerPawn>(PlayerClass, PlayerStart->GetActorLocation(), PlayerStart->GetActorRotation(), SpawnInfo);
	if(!PlayerPawn) return;
	OnPossess(PlayerPawn);
}

void ATP_PlayerController::MoveRight(float Amount)
{
	if(!GetPawn() || !GetPawn()->FindComponentByClass<UMeshComponent>() || Amount == 0) return;
	
	if(!TraceMove(Amount, GetPawn()->FindComponentByClass<UMeshComponent>())) return;
	FVector NewLocation = GetPawn()->FindComponentByClass<UMeshComponent>()->GetRelativeLocation();
	NewLocation.Y -= Amount * SpeedModify;
	GetPawn()->FindComponentByClass<UMeshComponent>()->SetRelativeLocation(NewLocation);
	if(GetNetMode() == NM_Client)
	{
		Server_MoveRight(Amount);
	}
}

bool ATP_PlayerController::TraceMove(float Amount, UPrimitiveComponent* ComponentLocation)
{
	if(!GetWorld() || !ComponentLocation) return false;

	FHitResult HitResult;
	FVector TraceEnd, TraceStart;
	TraceStart = ComponentLocation->GetComponentLocation();
	FVector Direction = ComponentLocation->GetRightVector();
	if(Amount > 0)
	{
		Direction = ComponentLocation->GetRightVector() * -1;
	}
	TraceEnd = TraceStart + Direction * TraceMaxDistance;
	FCollisionQueryParams CollisionParams;
	CollisionParams.AddIgnoredComponent(ComponentLocation);
	GetWorld()->LineTraceSingleByChannel(HitResult, TraceStart, TraceEnd, ECollisionChannel::ECC_Visibility, CollisionParams);
	if(HitResult.bBlockingHit)
	{
		return false;
	}
	return true;
}

void ATP_PlayerController::Server_MoveRight_Implementation(float Amount)
{
	MoveRight(Amount);
}

void ATP_PlayerController::Client_ShowWaitPlayerWidget_Implementation()
{
	const auto HUD = Cast<ATP_BaseHUD>(GetHUD());
	if(!HUD) return;

	HUD->SetVisibilityWidget(HUD->GetWaitPlayersWidget(), true);
	SetInputMode(FInputModeGameOnly());
}

void ATP_PlayerController::Client_HideWaitPlayerWidget_Implementation()
{
	const auto HUD = Cast<ATP_BaseHUD>(GetHUD());
	if(!HUD) return;
	
	HUD->SetVisibilityWidget(HUD->GetWaitPlayersWidget(), false);
	SetInputMode(FInputModeGameOnly());
}

void ATP_PlayerController::Client_ShowPlayerHUDWidget_Implementation()
{
	const auto HUD = Cast<ATP_BaseHUD>(GetHUD());
	if(!HUD) return;

	HUD->SetVisibilityWidget(HUD->GetPlayerHUDWidget(), true);
	SetInputMode(FInputModeGameOnly());
}

void ATP_PlayerController::Client_HidePlayerHUDWidget_Implementation()
{
	const auto HUD = Cast<ATP_BaseHUD>(GetHUD());
	if(!HUD) return;
	
	HUD->SetVisibilityWidget(HUD->GetPlayerHUDWidget(), false);
	SetInputMode(FInputModeGameOnly());
}

void ATP_PlayerController::AddGoal()
{
	if(!PlayerState) return;

	PlayerState->AddGoal();
	if(GetNetMode() == NM_Client)
	{
		Server_AddGoal();
	}
}

void ATP_PlayerController::Server_AddGoal_Implementation()
{
	AddGoal();
}

