// Fill out your copyright notice in the Description page of Project Settings.


#include "Ball/TP_BallActor.h"

#include "Game/TP_BaseGameMode.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Net/UnrealNetwork.h"

DEFINE_LOG_CATEGORY_STATIC(LogBallActor, All, All);

void ATP_BallActor::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ATP_BallActor, VelocityBall);
	DOREPLIFETIME(ATP_BallActor, SpeedBall);
	DOREPLIFETIME(ATP_BallActor, DeltaBall);
	DOREPLIFETIME(ATP_BallActor, DelayStartMove);
}

ATP_BallActor::ATP_BallActor()
{
	bReplicates = true;
 	PrimaryActorTick.bCanEverTick = true;

	SceneComponent = CreateDefaultSubobject<USceneComponent>("Scene");
	SetRootComponent(SceneComponent);
	MeshBall = CreateDefaultSubobject<UStaticMeshComponent>("StaticMesh");
	MeshBall->SetupAttachment(SceneComponent);

	SceneComponent->SetIsReplicated(true);
	MeshBall->SetIsReplicated(true);
}

void ATP_BallActor::BeginPlay()
{
	Super::BeginPlay();

	if(!GetWorld()) return;
	
	GetWorld()->GetTimerManager().SetTimer(StartMoveBallTimerManager, this, &ATP_BallActor::StartMove, 0.01f, false, DelayStartMove);
}

void ATP_BallActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ATP_BallActor::Server_StartMove_Implementation()
{
	StartMove();
}

void ATP_BallActor::StartMove()
{
	if(!GetWorld()) return;

	float VelocX = 1.0f;
	float VelocY = 1.0f;
	if(FMath::RandBool())
	{
		VelocX = -1;
	}
	if(FMath::RandBool())
	{
		VelocY = -1;
	}
	VelocityBall = FVector(VelocX, VelocY, 0.0f);
	OnRep_VelocityBall();
	GetWorld()->GetTimerManager().SetTimer(UpdateMoveBallTimerManager, this, &ATP_BallActor::MoveBall, DeltaBall, true, 0.0f);
	if(GetNetMode() == NM_Client)
	{
		Server_MoveBall();
	}
}

void ATP_BallActor::MoveBall()
{
	if(!GetWorld()) return;
	FVector TraceStart, TraceEnd, NewLocation;
	TraceStart = GetActorLocation();
	TraceEnd = TraceStart + VelocityBall * SpeedBall * DeltaBall;
	NewLocation = TraceEnd;
	FHitResult HitResult;
	GetWorld()->LineTraceSingleByChannel(HitResult, TraceStart, TraceEnd, ECollisionChannel::ECC_Visibility);
	if(HitResult.bBlockingHit)
	{
		VelocityBall = UKismetMathLibrary::MirrorVectorByNormal(VelocityBall, HitResult.ImpactNormal);
		APawn* PlayerPawn = Cast<APawn>(HitResult.GetActor());
		if(PlayerPawn)
		{
			SpeedBall = FMath::Clamp(SpeedBall + AmountSpeedPerHit, SpeedBall, MaxSpeedBall);
		}
		OnRep_VelocityBall();
		NewLocation = TraceStart + VelocityBall * SpeedBall * DeltaBall;
	}
	SetActorLocation(NewLocation);
	if(GetNetMode() == NM_Client)
	{
		Server_MoveBall();
	}
}

void ATP_BallActor::OnRep_VelocityBall()
{
	UE_LOG(LogBallActor, Display, TEXT("Velocity Ball Change. New value: X (%f) : Y (%f) : Z (%f)"), VelocityBall.X, VelocityBall.Y, VelocityBall.Z);
}

void ATP_BallActor::Server_MoveBall_Implementation()
{
	MoveBall();
}

